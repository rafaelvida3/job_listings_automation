"""Job listings automation package."""
